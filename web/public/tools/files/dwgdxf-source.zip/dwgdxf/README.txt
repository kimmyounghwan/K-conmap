K-건설맵 · DWG → DXF 바꾸기 (https://k-conmap.com/tools/dwgdxf) — 소스
=====================================================================

이 묶음은 GNU GPL 3.0 (COPYING) 을 따릅니다.
This bundle is licensed under the GNU General Public License v3.0 (see COPYING).

■ 들어 있는 것 / Contents
  dwgdxf.worker.js  브라우저 일꾼(Web Worker) — DWG 를 엔진으로 읽어 DXF 로 쓰고, 다듬기를 부릅니다
  dwgdxf.js         다듬기 — 엔진이 쓴 DXF 를 AutoCAD 가 받아들이게 바로잡는 부분(레이어 켜짐/꺼짐, 사전, 속성, 해치, 치수 …)
  libredwg-web/     쓰는 엔진의 package.json · README (고치지 않은 원본)

■ 변환 엔진 / Conversion engine (unmodified)
  @mlightcad/libredwg-web 0.7.14 (GPL-3.0)
    npm:     https://www.npmjs.com/package/@mlightcad/libredwg-web/v/0.7.14
    source:  https://github.com/mlightcad/libredwg-web
  built from LibreDWG (GPL-3.0), GNU project
    source:  https://www.gnu.org/software/libredwg/  ·  https://github.com/LibreDWG/libredwg
  사이트는 위 npm 0.7.14 의 dist/libredwg-web.js · wasm/libredwg-web.js · wasm/libredwg-web.wasm 을
  고치지 않고 그대로 씁니다. The site serves those three files from npm 0.7.14 without modification.

■ 문의 / Contact : 사이트 하단 «문의»
